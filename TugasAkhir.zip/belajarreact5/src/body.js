import React, { useState } from 'react';
import ImgAbout from "./ztn. (3) (1).png";
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import {
  BennerStyle, ButtonStyle, BennerText,
  AboutStyle, AboutImg, AboutHeading, AboutText, TestiForm, TestiStyle
} from "./StyledBody";

const Body = () => {
  const [testimonials, setTestimonials] = useState([]);
  const [inputAuthor, setInputAuthor] = useState('');
  const [inputText, setInputText] = useState('');

  const handleAuthorChange = (e) => {
    setInputAuthor(e.target.value);
  };

  const handleTextChange = (e) => {
    setInputText(e.target.value);
  };

  const addTestimonial = () => {
    if (inputAuthor.trim() !== '' && inputText.trim() !== '') {
      const newTestimonial = {
        author: inputAuthor,
        text: inputText,
      };
      setTestimonials([...testimonials, newTestimonial]);
      setInputAuthor('');
      setInputText('');
    }
  };

  const deleteTestimonial = (index) => {
    const updatedTestimonials = testimonials.filter((_, i) => i !== index);
    setTestimonials(updatedTestimonials);
  };

  const handleZtnClick = () => {
    window.location.href = 'https://shopee.co.id/zerotwentynine_st';
  }
  const handleDashboardClick = () => {
    window.location.href = 'https://shopee.co.id/zerotwentynine_st#product_list';
  }
  const handleProdukCklick = () => {
    window.location.href = 'https://shopee.co.id/Compass-Retrograde-low-cream-black-white-bw-41-42-i.40766396.7978607722?sp_atk=a5da53dd-b031-4ba4-a1d0-b6e937dd9bc2';
  }
  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 5
    },
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 3
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1
    }
  };
    return (
      <body>
  <BennerStyle>
      <BennerText>
          <h3>Beli Sepatu Yang berkualitas Dan harganya terjangkau</h3>
          <ButtonStyle onClick={handleZtnClick}>ZeroTwentyNine.ST</ButtonStyle>
      </BennerText>
  </BennerStyle>
  <AboutStyle>
      <AboutImg>
        <img src={ImgAbout} style={{height: "300px", width: "300px"}} />
      </AboutImg>
      <AboutText>
          <AboutHeading>ZeroTwentyNine.ST</AboutHeading>
          <p>ZeroTwentyNine.ST Menjual sepatu yang berkualitas dan harganya terjangkau,serta banyak variasinya  Menjual sepatu yang berkualitas dan harganya terjangkau,serta banyak variasinya.</p>
          <ButtonStyle onClick={handleDashboardClick}>Dashboard</ButtonStyle>
      </AboutText>
  </AboutStyle>
  <hr />
  <AboutStyle>
      <AboutText>
          <AboutHeading>ANEKA SEPATU</AboutHeading>
          <p style={{fontSize: "20px"}}>Kami menyediakan bebrapa pilihan merk sepatu lokal seperti Compass, Aerostreet dan Patrobas</p>
      </AboutText>
      <AboutImg>
        <img src="https://compass-ecom-bucket.s3-ap-southeast-1.amazonaws.com/images/productdetail/82fee0dd9cb3f8a4fdb775287069dc9873b5fa42.png" style={{height: "300px", width: "300px", backgroundColor:"#0000000"}} />
      </AboutImg>
  </AboutStyle>
  <hr />
  <div className="App">
  <Carousel responsive={responsive}>
    <div className="card">
      <img className="product--image" src="https://compass-ecom-bucket.s3-ap-southeast-1.amazonaws.com/images/productdetail/82fee0dd9cb3f8a4fdb775287069dc9873b5fa42.png" 
      style={{height: "450px", width: "435px"}} alt="product image" />
      <h2>Compass Gazelle Low Black and white</h2>
      <p className="price">Rp 408.000</p>
      <ButtonStyle onClick={handleProdukCklick}>Beli Sekarang</ButtonStyle>
    </div>
    <div className="card">
      <img className="product--image" src="https://compass-ecom-bucket.s3-ap-southeast-1.amazonaws.com/images/productdetail/8ef4fd8a48c4691613af59eedf65816be39b6db9.png" 
      style={{height: "450px", width: "435px"}} alt="product image" />
      <h2>Compass Gazelle Low Red and white</h2>
      <p className="price">Rp 408.000</p>
      <ButtonStyle onClick={handleProdukCklick}>Beli Sekarang</ButtonStyle>
    </div>
    <div className="card">
      <img className="product--image" src="https://compass-ecom-bucket.s3-ap-southeast-1.amazonaws.com/images/productdetail/51f9056f391f57cf03e52afa8411aba427f96118.png" 
      style={{height: "450px", width: "435px"}} alt="product image" />
      <h2>Compass Retrograde Low Triple Black</h2>
      <p className="price">Rp 538.000</p>
      <ButtonStyle onClick={handleProdukCklick}>Beli Sekarang</ButtonStyle>
    </div>
    <div className="card">
      <img className="product--image" src="https://compass-ecom-bucket.s3-ap-southeast-1.amazonaws.com/images/productdetail/3efe572df6528229114fc66ce9bc85d7400095df.png" 
      style={{height: "450px", width: "435px"}} alt="product image" />
      <h2>Compass Velocity Black and white</h2>
      <p className="price">Rp 798.000</p>
      <ButtonStyle onClick={handleProdukCklick}>Beli Sekarang</ButtonStyle>
    </div>
  </Carousel>;
  </div>
  
  <section>
    <div>
        <TestiForm>
            <h1>Testimonial App</h1>
            <label for="nama">Nama:</label>
            <input
                type="text"
                placeholder="Enter author..."
                value={inputAuthor}
                onChange={handleAuthorChange}
                />

            <label for="pesan">Pesan:</label>
            <textarea
                placeholder="Enter testimonial..."
                value={inputText}
                onChange={handleTextChange}
            ></textarea>
            <button onClick={addTestimonial}>Add Testimonial</button>
        </TestiForm>

        <TestiStyle className="testimonial-list">
        {testimonials.map((testimonial, index) => (
            <div className="box" key={index}>
            
                <h2 className="card-title">{testimonial.author}</h2>
                <p className="card-text">{testimonial.text}</p>
                <button onClick={() => deleteTestimonial(index)}>Delete</button>
            
            </div>
        ))}
        </TestiStyle>
    </div>
</section>
</body>
    );
}

export default Body;