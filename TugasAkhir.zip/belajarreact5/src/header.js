import React from "react";
import {NavStyle, UlStyle, AStyle} from "./StyledHeader";

function Header() {
  return (
    <NavStyle>
  <h3>ZeroTwentyNine.ST</h3>
  <UlStyle>
    <li><AStyle>Home</AStyle></li>
    <li><AStyle>About</AStyle></li>
    <li><AStyle>Work</AStyle></li>
    <li><AStyle>Careers</AStyle></li>
    <li><AStyle>Contact Us</AStyle></li>
  </UlStyle>
</NavStyle>
  );
}

export default Header;