import styled from 'styled-components';

export const StyledFooter = styled.footer`
    background-color: #eee;
    padding: 10px;
    text-align: center;
`;